import requests
import xml.etree.ElementTree as ET
from .base import Deal
from ..bot.db import put_deal

KEYWORDS = ["акция", "скид", "промо", "выгода"]

async def fetch_sitemap(store_slug, category, sitemap_url):
    r = requests.get(sitemap_url, timeout=20, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    try:
        root = ET.fromstring(r.text)
    except ET.ParseError:
        return 0
    added = 0
    for loc in root.findall(".//{*}loc"):
        url = (loc.text or "").strip()
        if not url:
            continue
        if not any(k in url.lower() for k in KEYWORDS):
            continue
        d = Deal(store_slug=store_slug, category=category, title="Страница акции", description=url, url=url, source=sitemap_url, score=0.5)
        if put_deal(d.as_dict()):
            added += 1
    return added