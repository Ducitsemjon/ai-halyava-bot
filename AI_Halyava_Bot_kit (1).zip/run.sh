#!/usr/bin/env bash
export PYTHONPATH=.
python -m bot.main
