import requests, hashlib, datetime
from bs4 import BeautifulSoup

def iso_now():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat()

def clean_text(x):
    return " ".join((x or "").split())

class Deal:
    def __init__(self, **kw):
        self.data = kw
    def as_dict(self):
        return self.data