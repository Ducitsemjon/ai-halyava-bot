import requests
from bs4 import BeautifulSoup
from .base import Deal, clean_text
from ..bot.db import put_deal

async def fetch_html_css(store_slug, category, url, item_selector, title_selector, link_selector, desc_selector=None):
    r = requests.get(url, timeout=15, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "lxml")
    items = soup.select(item_selector)[:100]
    added = 0
    for it in items:
        title_el = it.select_one(title_selector)
        link_el = it.select_one(link_selector)
        if not title_el or not link_el: 
            continue
        title = clean_text(title_el.get_text())
        link = link_el.get("href") or ""
        desc = ""
        if desc_selector:
            d_el = it.select_one(desc_selector)
            if d_el: desc = clean_text(d_el.get_text())
        d = Deal(store_slug=store_slug, category=category, title=title, description=desc, url=link, source=url, score=0.8)
        if put_deal(d.as_dict()):
            added += 1
    return added