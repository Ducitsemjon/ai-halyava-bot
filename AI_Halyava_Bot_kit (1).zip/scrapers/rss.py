import feedparser, datetime
from .base import Deal, clean_text
from ..bot.db import put_deal

async def fetch_rss(store_slug, category, url):
    feed = feedparser.parse(url)
    added = 0
    for e in feed.entries[:100]:
        title = clean_text(e.get("title",""))
        link = e.get("link","")
        summary = clean_text(e.get("summary",""))
        end_at = None
        d = Deal(store_slug=store_slug, category=category, title=title, description=summary, url=link, end_at=end_at, source=url, score=1.0)
        if put_deal(d.as_dict()):
            added += 1
    return added