import yaml, os, asyncio
from .rss import fetch_rss
from .html_css import fetch_html_css
from .sitemap import fetch_sitemap

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "stores.yaml")

async def run_all():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        conf = yaml.safe_load(f)
    total = 0
    for s in conf.get("stores", []):
        stype = s.get("type")
        if stype=="rss":
            total += await fetch_rss(s["store"], s.get("category","другое"), s["url"])
        elif stype=="html_css":
            total += await fetch_html_css(s["store"], s.get("category","другое"), s["url"], s["item_selector"], s["title_selector"], s["link_selector"], s.get("desc_selector"))
        elif stype=="sitemap":
            total += await fetch_sitemap(s["store"], s.get("category","другое"), s["url"])
    return total