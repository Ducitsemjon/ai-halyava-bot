import os, asyncio, datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from .db import init_db, upsert_user, get_sub, sub_active
from .payments import grant_trial, create_invoice_rub, redeem_promo
from .search import search

router = Router()

@router.message(Command("start"))
async def start(m: Message):
    upsert_user(m.from_user.id, m.from_user.username or "")
    sub = get_sub(m.from_user.id)
    if not sub:
        till = grant_trial(m.from_user.id, int(os.environ.get("TRIAL_DAYS", 3)))
        await m.answer(f"Привет! Включил бесплатный триал до {till}. Команды: /search, /buy, /profile, /stores, /categories, /help")
    else:
        await m.answer("Снова ты! /search магазин [категория] — попробуем?")

@router.message(Command("help"))
async def help_cmd(m: Message):
    await m.answer("Команды:\n/search <магазин> [категория]\n/stores — список магазинов\n/categories — категории\n/buy — подписка 249₽/мес\n/profile — статус\n/redeem <код> — активировать промокод")

@router.message(Command("profile"))
async def profile(m: Message):
    sub = get_sub(m.from_user.id)
    if not sub:
        await m.answer("Статус: нет подписки. /buy — оформить")
    else:
        await m.answer(f"Статус: {sub['status']} до {sub['until']}")

@router.message(Command("buy"))
async def buy(m: Message):
    text = create_invoice_rub(m.from_user.id)
    await m.answer("Подписка 249₽/мес. " + text)

@router.message(Command("redeem"))
async def redeem(m: Message):
    parts = m.text.split(maxsplit=1)
    if len(parts)<2:
        return await m.answer("Формат: /redeem КОД")
    ok = redeem_promo(m.from_user.id, parts[1].strip())
    if ok:
        await m.answer("Подписка активирована по коду. /profile — проверить")
    else:
        await m.answer("Код неверный или уже использован.")

@router.message(Command("stores"))
async def stores(m: Message):
    await m.answer("Примеры: ozon, wb, sber, magnit. (Добавь свои в data/stores.yaml)")

@router.message(Command("categories"))
async def categories(m: Message):
    await m.answer("Категории: электроника, продукты, подписки, доставка, другое.")

@router.message(Command("search"))
async def search_cmd(m: Message):
    args = m.text.split()[1:]
    if not args:
        return await m.answer("Формат: /search <магазин> [категория]")
    store = args[0].lower()
    category = args[1].lower() if len(args)>1 else None

    if not sub_active(m.from_user.id):
        await m.answer("Нужна активная подписка. /buy — оформить (есть триал в /start)")
        return
    results = search(store, category, limit=5)
    if not results:
        await m.answer("Пока пусто. Попробуй другой магазин/категорию.")
    else:
        for r in results:
            await m.answer(r, disable_web_page_preview=True)