import sqlite3, os, json, datetime, hashlib

DB_PATH = os.environ.get("DB_PATH", "halyava.db")

def connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = connect()
    with open(os.path.join(os.path.dirname(__file__), "models.sql"), "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.commit()
    return conn

def now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat()

def upsert_user(user_id, username):
    conn = connect()
    conn.execute("INSERT OR IGNORE INTO users(user_id, username) VALUES(?,?)", (user_id, username))
    conn.commit()

def get_sub(user_id):
    conn = connect()
    cur = conn.execute("SELECT status, until FROM subscriptions WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    if not row: return None
    return dict(row)

def set_sub(user_id, status, until_iso, plan="monthly"):
    conn = connect()
    conn.execute("INSERT INTO subscriptions(user_id, status, until, plan, updated_at) VALUES(?,?,?,?,?)                  ON CONFLICT(user_id) DO UPDATE SET status=excluded.status, until=excluded.until, updated_at=excluded.updated_at",
                 (user_id, status, until_iso, plan, now_iso()))
    conn.commit()

def sub_active(user_id):
    sub = get_sub(user_id)
    if not sub: return False
    try:
        until = datetime.datetime.fromisoformat(sub["until"])
        return until >= datetime.datetime.utcnow()
    except Exception:
        return False

def put_deal(d):
    conn = connect()
    h = hashlib.sha256((d.get("url","") + d.get("title","")).encode("utf-8")).hexdigest()
    d["hash"] = h
    keys = ["store_slug","category","title","description","url","price_old","price_new","cashback","coupon_code","start_at","end_at","source","score","hash"]
    vals = [d.get(k) for k in keys]
    try:
        conn.execute("INSERT INTO deals("+",".join(keys)+") VALUES("+",".join(["?"]*len(keys))+")", vals)
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False

def search_deals(store=None, category=None, limit=5):
    conn = connect()
    q = "SELECT * FROM deals WHERE 1=1"
    args = []
    if store:
        q += " AND store_slug=?"
        args.append(store)
    if category:
        q += " AND (category=? OR title LIKE ? OR description LIKE ?)"
        args.extend([category, f"%{category}%", f"%{category}%"])
    q += " AND (end_at IS NULL OR end_at >= ?)"
    args.append(now_iso())
    q += " ORDER BY score DESC, end_at ASC NULLS LAST, created_at DESC LIMIT ?"
    args.append(limit)
    cur = conn.execute(q, tuple(args))
    return [dict(r) for r in cur.fetchall()]