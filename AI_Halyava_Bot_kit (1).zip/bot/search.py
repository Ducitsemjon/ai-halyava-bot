from .db import search_deals

def format_deal(d):
    price = ""
    if d.get("price_new"):
        if d.get("price_old"):
            price = f"Цена: {d['price_new']} (было {d['price_old']})\n"
        else:
            price = f"Цена: {d['price_new']}\n"
    cb = f"Кэшбэк: {d['cashback']}\n" if d.get("cashback") else ""
    coupon = f"Промокод: `{d['coupon_code']}`\n" if d.get("coupon_code") else ""
    deadline = f"Дедлайн: {d['end_at']}\n" if d.get("end_at") else ""
    return (f"🛒 {d['store_slug']} • {d.get('category') or 'без категории'}\n"
            f"🧩 {d['title']}\n"
            f"{price}{cb}{coupon}{deadline}"
            f"🔗 {d['url']}")

def search(store=None, category=None, limit=5):
    deals = search_deals(store, category, limit)
    return [format_deal(d) for d in deals]