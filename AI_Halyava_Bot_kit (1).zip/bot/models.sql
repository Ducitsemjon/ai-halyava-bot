-- Users
CREATE TABLE IF NOT EXISTS users (
  user_id INTEGER PRIMARY KEY,
  username TEXT,
  is_admin INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
  user_id INTEGER PRIMARY KEY,
  status TEXT, -- active|expired|trial
  until TEXT,  -- ISO date
  plan TEXT,   -- monthly
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Stores
CREATE TABLE IF NOT EXISTS stores (
  slug TEXT PRIMARY KEY,
  name TEXT,
  categories TEXT
);

-- Deals
CREATE TABLE IF NOT EXISTS deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  store_slug TEXT,
  category TEXT,
  title TEXT,
  description TEXT,
  url TEXT,
  price_old REAL,
  price_new REAL,
  cashback REAL,
  coupon_code TEXT,
  start_at TEXT,
  end_at TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  source TEXT,
  hash TEXT UNIQUE,
  score REAL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_deals_store ON deals(store_slug);
CREATE INDEX IF NOT EXISTS idx_deals_cat ON deals(category);
CREATE INDEX IF NOT EXISTS idx_deals_end_at ON deals(end_at);
CREATE INDEX IF NOT EXISTS idx_deals_created_at ON deals(created_at);