import asyncio, os
from aiogram import Bot, Dispatcher
from dotenv import load_dotenv
from .db import init_db
from .handlers import router
from .scheduler import start_scheduler

def main():
    load_dotenv()
    init_db()
    bot = Bot(token=os.environ["BOT_TOKEN"], parse_mode="HTML")
    dp = Dispatcher()
    dp.include_router(router)
    asyncio.run(run(dp, bot))

async def run(dp, bot):
    await start_scheduler()
    await dp.start_polling(bot)

if __name__ == "__main__":
    main()