import os, asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from ..scrapers.runner import run_all

async def job():
    try:
        count = await run_all()
        print(f"[SCRAPER] обновлено позиций: {count}")
    except Exception as e:
        print("[SCRAPER] error:", e)

async def start_scheduler():
    sch = AsyncIOScheduler(timezone=os.environ.get("TIMEZONE","Europe/Moscow"))
    sch.add_job(job, "interval", hours=2, id="scrape")
    sch.start()