import os, datetime
from .db import set_sub

MONTH_PRICE = int(os.environ.get("MONTHLY_PRICE_RUB", 249))

def grant_trial(user_id, days=3):
    until = (datetime.datetime.utcnow() + datetime.timedelta(days=days)).replace(microsecond=0).isoformat()
    set_sub(user_id, "trial", until)
    return until

def grant_month(user_id, months=1):
    until = (datetime.datetime.utcnow() + datetime.timedelta(days=30*months)).replace(microsecond=0).isoformat()
    set_sub(user_id, "active", until)
    return until

# Заглушки интеграций. Реальные провайдеры: Telegram Stars, CryptoBot, ЮKassa
def create_invoice_rub(user_id):
    # Верни текст с инструкцией или ссылкой на оплату
    return f"Оплата подписки {MONTH_PRICE}₽/мес. После оплаты пришлите чек боту или используйте промокод от админа."

# Промокоды для MVP
PROMO_CODES = {}

def generate_promo(code:str, months:int=1):
    PROMO_CODES[code] = months

def redeem_promo(user_id, code:str):
    months = PROMO_CODES.get(code)
    if not months:
        return False
    grant_month(user_id, months)
    del PROMO_CODES[code]
    return True